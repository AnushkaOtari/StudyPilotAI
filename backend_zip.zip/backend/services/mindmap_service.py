import os
import json
from dotenv import load_dotenv
from google import genai

from rag.rag_pipeline import retrieve_context, has_vector_store
from schemas.mindmap_schema import MindMapResponse

load_dotenv()

client = genai.Client(
    api_key=os.getenv("GOOGLE_API_KEY")
)

def _friendly_generation_error(e):
    msg = str(e).lower()

    if isinstance(e, json.JSONDecodeError) or "json" in msg:
        return "The AI returned an unexpected response format."

    if "timeout" in msg or "deadline" in msg:
        return "Mind map generation timed out. Please try again."

    return "Unable to generate the mind map right now."